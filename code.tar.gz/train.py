import torch
import torch.optim as optim
import torch.nn as nn
import argparse
import os
import random
from torch.autograd import Variable
from torch.utils.data import DataLoader
import data_utils as utils
import numpy as np
import time
import modules.utils as utility




parser = argparse.ArgumentParser()
parser.add_argument('--lr', default=0.0002, type=float, help='learning rate')
parser.add_argument('--beta1', default=0.9, type=float, help='momentum term for adam')
parser.add_argument('--batch_size', default=4, type=int, help='batch size')
parser.add_argument('--log_dir', default='logs', help='base directory to save logs')
parser.add_argument('--model_dir', default='', help='base directory to save logs')
parser.add_argument('--name', default='', help='identifier for directory')
parser.add_argument('--gpu', default='0', help='which gpu to use')
parser.add_argument('--data_root', default='data', help='root directory for data')
parser.add_argument('--optimizer', default='adam', help='optimizer to train with')
parser.add_argument('--niter', type=int, default=200, help='number of epochs to train for')
parser.add_argument('--seed', default=1, type=int, help='manual seed')
parser.add_argument('--epoch_size', type=int, default=1000, help='epoch size')
parser.add_argument('--image_width', type=int, default=128, help='the height / width of the input image to network')
parser.add_argument('--channels', default=3, type=int)
parser.add_argument('--dataset', default='tower', help='dataset to train with')
parser.add_argument('--n_past', type=int, default=1, help='number of frames to condition on')
parser.add_argument('--n_future', type=int, default=10, help='number of frames to predict')
parser.add_argument('--n_eval', type=int, default=11, help='number of frames to predict at eval time')
parser.add_argument('--seq_len', type=int, default=11, help='number of frames to predict at eval time')
parser.add_argument('--rnn_size', type=int, default=570, help='dimensionality of hidden layer')
parser.add_argument('--slot_size', type=int, default=15, help='channel size for each slot')
parser.add_argument('--wh', type=int, default=8, help='width and height for each slot')
parser.add_argument('--posterior_rnn_layers', type=int, default=2, help='number of layers')
parser.add_argument('--predictor_rnn_layers', type=int, default=2, help='number of layers')
parser.add_argument('--z_dim', type=int, default=32, help='dimensionality of z_t')
parser.add_argument('--g_dim', type=int, default=570,
                    help='dimensionality of encoder output vector and decoder input vector')
parser.add_argument('--beta', type=float, default=4, help='weighting on KL to prior')
parser.add_argument('--model', default='revnet', help='model type (revnet|dcgan | vgg)')
parser.add_argument('--data_threads', type=int, default=2, help='number of data loading threads')
parser.add_argument('--num_digits', type=int, default=2, help='number of digits for moving mnist')
parser.add_argument('--last_frame_skip', action='store_true',
                    help='if true, skip connections go between frame t and frame t+t rather than last ground truth frame')


opt = parser.parse_args()



if opt.model_dir != '':
    saved_model = torch.load('%s/model.pth' % opt.model_dir)
    optimizer = opt.optimizer
    model_dir = opt.model_dir
    opt = saved_model['opt']
    opt.optimizer = optimizer
    opt.model_dir = model_dir
    opt.log_dir = '%s/continued' % opt.log_dir
else:
    name = 'model_tower_rand=%s%dx%d-rnn_size=%d-predictor-posterior-rnn_layers=%d-%d-n_past=%d-n_future=%d-lr=%.4f-g_dim=%d-z_dim=%d-last_frame_skip=%d-beta=%.7f%s' % (opt.model, opt.image_width, opt.image_width, opt.rnn_size, opt.predictor_rnn_layers, opt.posterior_rnn_layers, opt.n_past, opt.n_future, opt.lr, opt.g_dim, opt.z_dim, opt.last_frame_skip, opt.beta, opt.name)
    if opt.dataset == 'smmnist':
        opt.log_dir = '%s/%s-%d/%s' % (opt.log_dir, opt.dataset, opt.num_digits, name)
    else:
        opt.log_dir = '%s/%s/%s' % (opt.log_dir, opt.dataset, name)

os.makedirs('%s/gen/' % opt.log_dir, exist_ok=True)
os.makedirs('%s/plots/' % opt.log_dir, exist_ok=True)


os.environ["CUDA_VISIBLE_DEVICES"] = opt.gpu
opt.max_step = opt.n_past + opt.n_future
print("Random Seed: ", opt.seed)
random.seed(opt.seed)
torch.manual_seed(opt.seed)
torch.cuda.manual_seed_all(opt.seed)
dtype = torch.cuda.FloatTensor

# ---------------- optimizers ----------------
if opt.optimizer == 'adam':
    opt.optimizer = optim.Adam

# ---------------- load the models  ----------------
print(opt)

from modules.cnn import  autoencoder, concept_slot
from modules.rnn import  stochastic, predictor



posterior = stochastic(opt.g_dim, opt.rnn_size, opt.z_dim, opt.posterior_rnn_layers,opt.batch_size,wh=opt.wh)
prior = stochastic(opt.g_dim, opt.rnn_size, opt.z_dim,  opt.posterior_rnn_layers,opt.batch_size,wh=opt.wh)
frame_predictor = predictor(opt.g_dim + opt.z_dim, opt.rnn_size + opt.z_dim, opt.channels * 512, opt.predictor_rnn_layers,opt.batch_size,wh=opt.wh)
encoder = autoencoder(nBlocks=[2,2,2,2], nStrides=[1, 2, 2,2],
                    nChannels=None, init_ds = 2,
                    dropout_rate=0., affineBN=True, in_shape=[opt.channels*2, opt.image_width, opt.image_width],
                    mult=2)
concept_slot =  concept_slot(opt.channels * 512, opt.rnn_size)



frame_predictor_optimizer = opt.optimizer(frame_predictor.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
posterior_optimizer = opt.optimizer(posterior.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
prior_optimizer = opt.optimizer(prior.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
encoder_optimizer = opt.optimizer(encoder.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))
concept_slot_optimizer = opt.optimizer(concept_slot.parameters(), lr=opt.lr, betas=(opt.beta1, 0.999))






# --------- loss functions ------------------------------------
mse_criterion = nn.MSELoss()

def kl_criterion(mu1, logvar1, mu2, logvar2):
    sigma1 = logvar1.mul(0.5).exp()
    sigma2 = logvar2.mul(0.5).exp()
    kld = torch.log(sigma2/sigma1) + (torch.exp(logvar1) + (mu1 - mu2)**2)/(2*torch.exp(logvar2)) - 1/2
    kld = kld.view(opt.batch_size,-1).sum(dim=1)
    return kld.sum() / opt.batch_size




# --------- transfer to gpu ------------------------------------
frame_predictor.cuda()
posterior.cuda()
prior.cuda()
encoder.cuda()
concept_slot.cuda()
mse_criterion.cuda()



# --------- load a dataset ------------------------------------
opt.type = 0
train_data_0, test_data_0 = utils.load_dataset(opt)
train_loader_0 = DataLoader(train_data_0,
                          num_workers=opt.data_threads,
                          batch_size=opt.batch_size,
                          shuffle=True,
                          drop_last=True,
                          pin_memory=True)

test_loader_0 = DataLoader(test_data_0,
                         num_workers=opt.data_threads,
                         batch_size=opt.batch_size,
                         shuffle=True,
                         drop_last=True,
                         pin_memory=True)


def get_training_batch_0():
    while True:
        for sequence,label1,label2 in train_loader_0:
            batch = sequence
            yield batch, label1, label2


training_batch_generator_0 = get_training_batch_0()


def get_testing_batch_0():
    while True:
        for sequence, label1, label2 in test_loader_0:
            batch = sequence
            yield batch, label1, label2


testing_batch_generator_0 = get_testing_batch_0()



def plot(x, epoch,label1,label2):
    nsample = 8
    gen_seq = [[] for i in range(nsample)]
    gt_seq = [x[i] for i in range(len(x))]
    label1 = label1.cuda()
    label2 = label2.cuda()

    for s in range(nsample):
        frame_predictor.hidden = frame_predictor.init_hidden()
        posterior.hidden = posterior.init_hidden()
        prior.hidden = prior.init_hidden()
        gen_seq[s].append(x[0])
        x_in = x[0]
        for i in range(1, opt.n_eval):
            h = encoder(torch.cat((x_in,x_in),1))

            if i <= 5:
                act, obj1, obj2 = label1[:, :4], label1[:, 4:21], label1[:, 21:38]
            else:
                act, obj1, obj2 = label2[:, :4], label2[:, 4:21], label2[:, 21:38]

            h_in = concept_slot(torch.cat((h[0],h[1]),1),act, obj1, obj2)
            h_in = h_in.detach()


            k_t, _, _ = prior(h_in)
            h_pred = (frame_predictor(torch.cat((h_in, k_t), 1))).detach()
            x_in = encoder((h[0] + h_pred[:, :768], h[1] + h_pred[:, 768:]), False)[:, :3, :, :].detach()
            gen_seq[s].append(x_in)

    to_plot = []
    eval = 0
    gifs = [[] for t in range(opt.n_eval)]
    nrow = min(opt.batch_size,16)
    for i in range(nrow):
        # ground truth sequence
        row = []
        for t in range(opt.n_eval):
            row.append(gt_seq[t][i])
        to_plot.append(row)

        # best sequence
        min_mse = 1e7
        for s in range(nsample):
            mse = 0
            for t in range(opt.n_eval):
                mse += torch.sum((gt_seq[t][i].data.cpu() - gen_seq[s][t][i].data.cpu()) ** 2)
            if mse < min_mse:
                min_mse = mse
                min_idx = s
        eval += min_mse
        s_list = [min_idx,0,1,2,3]
        for ss in range(len(s_list)):
            s = s_list[ss]
            row = []
            for t in range(opt.n_eval):
                row.append(gen_seq[s][t][i])
            to_plot.append(row)
        for t in range(opt.n_eval):
            row = []
            row.append(gt_seq[t][i])
            for ss in range(len(s_list)):
                s = s_list[ss]
                row.append(gen_seq[s][t][i])
            gifs[t].append(row)

    fname = '%s/gen/sample_%d.png' % (opt.log_dir, epoch)
    utils.save_tensors_image(fname, to_plot)

    fname = '%s/gen/sample_%d.gif' % (opt.log_dir, epoch)
    utils.save_gif(fname, gifs)
    return eval



# --------- training funtions ------------------------------------
def train(x,label1,label2,epoch,iter):
    kld = 0
    log = 0


    frame_predictor.zero_grad()
    posterior.zero_grad()
    prior.zero_grad()
    encoder.zero_grad()
    concept_slot.zero_grad()



    # initialize the hidden state.
    frame_predictor.hidden = frame_predictor.init_hidden()
    posterior.hidden = posterior.init_hidden()
    prior.hidden = prior.init_hidden()


    label1 = label1.cuda()
    label2 = label2.cuda()

    first = True
    for i in range(1, opt.n_past + opt.n_future):

        p =  0.18 + 0.02 * epoch / float(opt.niter)
        if random.uniform(0, 1) >= p or first:
            h = encoder(torch.cat((x[i - 1], x[i - 1]),1))
            first = False
        else:
            h = encoder(torch.cat((x_pred, x_pred),1))
        h_target = encoder(torch.cat((x[i],x[i]),1))

        if i <= 5:
            act, obj1, obj2 = label1[:, :4], label1[:, 4:21], label1[:, 21:38]
        else:
            act, obj1, obj2 = label2[:, :4], label2[:, 4:21], label2[:, 21:38]
        h_in = concept_slot(torch.cat((h[0],h[1]),1),act, obj1, obj2)
        h_target = concept_slot(torch.cat((h_target[0],h_target[1]),1), act, obj1, obj2)
        k_t, mu, logvar = posterior(h_target)
        _, mu_p, logvar_p = prior(h_in)
        h_pred = frame_predictor(torch.cat((h_in, k_t),1))

        x_pred = encoder((h[0] + h_pred[:, :768], h[1] + h_pred[:, 768:]), False)[:, :3, :, :]

        log += utility.neg_logprob(x_pred, x[i], scale=1).sum()
        kld += kl_criterion(mu, logvar, mu_p, logvar_p)



    loss = log + kld * opt.beta
    loss.backward()

    frame_predictor_optimizer.step()
    posterior_optimizer.step()
    prior_optimizer.step()
    encoder_optimizer.step()
    concept_slot_optimizer.step()


    return log.sum().item() / (opt.n_past + opt.n_future), kld.data.cpu().numpy() / (opt.n_past + opt.n_future)

# xt,labelt = next(testing_batch_generator)
# --------- training loop ------------------------------------
for epoch in range(opt.niter):
    frame_predictor.train()
    posterior.train()
    prior.train()
    encoder.train()
    concept_slot.train()



    epoch_mse = 0
    epoch_kld = 0


    for i in range(opt.epoch_size):
        x, label1, label2 = next(training_batch_generator_0)
        x = x.transpose(0,1).cuda()
        # train frame_predictor
        mse, kld = train(x,label1,label2,epoch,i)
        epoch_mse += mse
        epoch_kld += kld

    with torch.no_grad():
        frame_predictor.eval()
        encoder.eval()
        concept_slot.eval()
        posterior.eval()
        prior.eval()

        x, label1, label2= next(testing_batch_generator_0)

        x = x.transpose(0,1).cuda()
        evalmse = plot(x, epoch,label1,label2)

    print('[%02d] mse loss: %.5f | kld loss: %.5f | eval: %.5f (%d)' % (
    epoch, epoch_mse / opt.epoch_size, epoch_kld / opt.epoch_size, evalmse ,epoch * opt.epoch_size * opt.batch_size))


    #
    # save the model
    if epoch % 10 == 0:
        torch.save({
            'encoder': encoder,
            'concept_slot': concept_slot,
            'frame_predictor': frame_predictor,
            'posterior': posterior,
            'prior': prior,
            'opt': opt},
            '%s/model_%s.pth' % (opt.log_dir,epoch))


    torch.save({
        'encoder': encoder,
        'concept_slot': concept_slot,
        'frame_predictor': frame_predictor,
        'posterior': posterior,
        'prior': prior,
        'opt': opt},
        '%s/model.pth' % opt.log_dir)