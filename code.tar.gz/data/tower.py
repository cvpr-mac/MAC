import random
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset
import os
import json




class TOWER(Dataset):
    def __init__(self, mode='train', clip_len = 21):
        super(TOWER, self).__init__()
        self.mode = mode
        with open('/home/wei/Documents/tower/%s.npy' % mode, 'rb') as f:
            self.fn = np.load(f,allow_pickle=True)
        self.clip_len = clip_len
        self.act_len = 10
        # self.flip_prop = 0.5

    def __getitem__(self, index):
        info = self.fn[index]
        dir = info[0]

        label1 = self.txt2digits(info[2])
        label2 = self.txt2digits(info[3])
        t1, t2, t3, num_l = info[1]
        noise = 5
        if t1 == 0:
            t1 += random.randint(0, 15)
        else:
            t1 += random.randint(-noise, noise)
        t2 += random.randint(-noise, noise)
        if t3 + 5 > num_l:
            t3 -= random.randint(0, noise)
        else:
            t3 += random.randint(-noise, noise)
        t3 = np.min((num_l, t3))
        samp1 = np.linspace(t1, t2, self.act_len+1).astype(int)
        samp2 = np.linspace(t2, t3, self.act_len+1).astype(int)
        gap1 = int((samp1[1] - samp1[0]) / 4)
        gap2 = int((samp2[1] - samp2[0]) / 4)
        # gap1 = noise
        # gap2 = noise
        time = list(samp1) + list(samp2[1:])
        nc = [0, self.act_len, self.act_len * 2]
        frame_list = []

        for t in range(self.clip_len):
            if t not in nc:
                if t < self.act_len:
                    readpath = dir + '%03d.jpg' % (int(time[t]) + random.randint(-gap1, gap1))
                else:
                    readpath = dir + '%03d.jpg' % (int(time[t]) + random.randint(-gap2, gap2))
            else:
                readpath = dir + '%03d.jpg' % time[t]
            frame = cv2.imread(readpath)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = frame / 255.0
            frame = frame.transpose(2, 0, 1)
            frame_list.append(frame)
        frames = np.stack(frame_list)
        # frames = frames.transpose(1, 0, 2, 3)
        frames = torch.from_numpy(frames).float()
        return frames, label1,label2


    def txt2digits(self,label):
        # label = [1,1] + [int(i) for i in list(label)]
        label =  [int(i) for i in list(label)]
        return torch.from_numpy(np.asarray(label)).float()



    def horizontal_flip(self, prob, images):
        if np.random.uniform() < prob:
            images = images.flip((-1))
        return images



    def __len__(self):
        return len(self.fn)


